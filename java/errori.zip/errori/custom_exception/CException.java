package custom_exception;
/**
 * custom exception */

public class CException extends Exception {
    public CException(String message) {
        super(message);
    }
}
